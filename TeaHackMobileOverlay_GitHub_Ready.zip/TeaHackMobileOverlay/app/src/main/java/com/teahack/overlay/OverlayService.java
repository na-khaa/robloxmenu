package com.teahack.overlay;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout panel;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private android.content.SharedPreferences prefs;
    private int blue=0xff65a6ff, white=0xfff0f4ff;
    private GradientDrawable bg(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    @Override public void onCreate(){super.onCreate(); prefs=getSharedPreferences("settings",MODE_PRIVATE); createNotification(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); makeBubble(); makePanel();}
    private void createNotification(){
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("overlay","Floating menu",NotificationManager.IMPORTANCE_LOW));
        Intent launch=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,"overlay").setContentTitle("TeaHack floating menu").setContentText("Overlay running — tap to manage").setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(pi).setOngoing(true).build();
        startForeground(1,n);
    }
    private WindowManager.LayoutParams params(int w,int h,int x,int y){ WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP|Gravity.START;p.x=x;p.y=y;return p; }
    private void makeBubble(){
        bubble=new TextView(this);bubble.setText("TH");bubble.setTextColor(white);bubble.setTextSize(17);bubble.setGravity(Gravity.CENTER);bubble.setTypeface(null,1);bubble.setBackground(bg(blue,40));
        bubbleParams=params(dp(55),dp(55),dp(12),dp(160));wm.addView(bubble,bubbleParams);
        bubble.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int px,py;boolean moved;
            @Override public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getAction()){
                case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();px=bubbleParams.x;py=bubbleParams.y;moved=false;return true;
                case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)>8||Math.abs(dy)>8)moved=true;bubbleParams.x=px+(int)dx;bubbleParams.y=py+(int)dy;wm.updateViewLayout(bubble,bubbleParams);return true;
                case MotionEvent.ACTION_UP:if(!moved)panel.setVisibility(panel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);return true;
            }return false;}});
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(white);t.setPadding(dp(10),dp(9),dp(10),dp(9));return t;}
    private void toggle(LinearLayout parent,String name){Switch s=new Switch(this);s.setText(name);s.setTextColor(white);s.setPadding(dp(10),dp(8),dp(10),dp(8));s.setChecked(prefs.getBoolean(name,false));s.setOnCheckedChangeListener((b,checked)->prefs.edit().putBoolean(name,checked).apply());parent.addView(s);}
    private void slider(LinearLayout parent,String name,int min,int max,int initial){TextView title=label(name+": "+prefs.getInt(name,initial),13);parent.addView(title);SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(prefs.getInt(name,initial)-min);parent.addView(bar);bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int progress,boolean user){int value=min+progress;title.setText(name+": "+value);if(user)prefs.edit().putInt(name,value).apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});}
    private void makePanel(){
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(12),dp(12),dp(12),dp(12));panel.setBackground(bg(0xff151b29,dp(16)));
        panel.addView(label("TEAHACK MOBILE  •  V1",18));
        LinearLayout tabs=new LinearLayout(this);panel.addView(tabs);
        ScrollView scroll=new ScrollView(this);panel.addView(scroll,new LinearLayout.LayoutParams(-1,dp(320)));
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);scroll.addView(body);
        String[] names={"Visual","Movement","Settings"};for(String tab:names){Button b=new Button(this);b.setText(tab);b.setTextSize(11);tabs.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));b.setOnClickListener(v->showTab(body,tab));}
        TextView disclaimer=label("Overlay UI only • Roblox game state is not accessed",11);disclaimer.setTextColor(0xffaebbd1);panel.addView(disclaimer);
        panelParams=params(dp(320),-2,dp(70),dp(100));wm.addView(panel,panelParams);panel.setVisibility(View.GONE);showTab(body,"Visual");
    }
    private void showTab(LinearLayout body,String tab){body.removeAllViews();if(tab.equals("Visual")){body.addView(label("Visual preferences (display-only)",14));toggle(body,"Player ESP");toggle(body,"NPC ESP");toggle(body,"Tracer Lines");toggle(body,"Distance Labels");slider(body,"ESP Range",50,1000,300);}else if(tab.equals("Movement")){body.addView(label("Movement presets (not applied to Roblox)",14));toggle(body,"Fast Run");toggle(body,"High Jump");toggle(body,"Infinite Jump");slider(body,"Walk Speed",16,100,32);slider(body,"Jump Power",50,200,90);}else{body.addView(label("Tap TH to minimize. Drag TH to move.",14));Button hide=new Button(this);hide.setText("HIDE MENU");body.addView(hide);hide.setOnClickListener(v->panel.setVisibility(View.GONE));Button stop=new Button(this);stop.setText("STOP OVERLAY");body.addView(stop);stop.setOnClickListener(v->stopSelf());}}
    @Override public void onDestroy(){if(wm!=null){if(panel!=null)wm.removeView(panel);if(bubble!=null)wm.removeView(bubble);}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
