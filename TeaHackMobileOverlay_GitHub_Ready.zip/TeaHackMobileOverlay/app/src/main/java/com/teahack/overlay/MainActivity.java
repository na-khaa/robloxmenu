package com.teahack.overlay;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(32,56,32,32); root.setBackgroundColor(Color.rgb(16,20,30));
        TextView heading = new TextView(this); heading.setText("TEAHACK MOBILE OVERLAY"); heading.setTextSize(22); heading.setTextColor(Color.WHITE); root.addView(heading);
        status = new TextView(this); status.setTextColor(0xffbbc7df); status.setPadding(0,24,0,24); root.addView(status);
        Button start = new Button(this); start.setText("START FLOATING MENU"); root.addView(start);
        Button stop = new Button(this); stop.setText("STOP OVERLAY"); root.addView(stop);
        TextView note = new TextView(this); note.setText("Independent Android overlay only. Does not access Roblox game data or modify game movement."); note.setTextColor(0xffaebbd1); note.setPadding(0,28,0,0); root.addView(note);
        setContentView(root);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i);
            } else { Intent i = new Intent(this, OverlayService.class); if (Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
    }
    @Override protected void onResume() { super.onResume(); if (status!=null) status.setText(Settings.canDrawOverlays(this)?"Overlay permission: Granted":"Overlay permission: Tap START to grant"); }
}
