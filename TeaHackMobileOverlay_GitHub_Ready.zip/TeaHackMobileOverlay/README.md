# TeaHack Mobile Floating Overlay V1

A standalone Android floating menu that displays over other apps, including Roblox when Android allows overlays.

## Build
1. Open the project folder in Android Studio (recent version supporting Android Gradle Plugin 8.7.3).
2. Install Android SDK Platform 35 and JDK 17 if prompted.
3. Run **Build > Build APK(s)**, or `gradle assembleDebug` with Gradle 8.9+ installed.
4. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android device.
5. Launch TeaHack Mobile Overlay, tap START, grant **Display over other apps**, then tap START again.
6. Open Roblox and use the draggable TH bubble. Some Android devices or apps restrict overlays.

## Scope
The floating window, tabs, toggles, sliders, dragging, minimize and persisted preferences work independently of Roblox. The ESP and movement labels are configuration previews only; they do not read Roblox memory, display actual players, or modify WalkSpeed, JumpPower, or game state. No Roblox injection or accessibility automation is included.

## Notes
- Android 8.0+; target SDK 35; foreground service with persistent notification.
- The source has not been compiled in this environment (Android SDK/Gradle not available here).
